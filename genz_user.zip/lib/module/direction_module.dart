class Direction{
  String? humanReadableAddress;
  String? locationName;
  String? locationId;
  double? locationLatitude;
  double? locationLongitude;


  Direction({this.humanReadableAddress, this.locationId, this.locationLatitude, this.locationLongitude, this.locationName});

}