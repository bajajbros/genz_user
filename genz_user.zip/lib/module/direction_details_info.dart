class DirectionDetailsInfo {
  int? distanceValue;
  int? durationValue;
  String? ePoint;
  String? distanceText;
  String? durationText;


  DirectionDetailsInfo({
    this.distanceText,
    this.distanceValue,
    this.durationText,
    this.durationValue,
    this.ePoint
  });


}