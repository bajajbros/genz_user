
import 'api_value.dart';

final Uri customerLogin = Uri.parse('${baseUrl}users/login');

final Uri customerSignup = Uri.parse('${baseUrl}users/signup');