// import 'dart:async';
// import 'dart:convert';
// import 'dart:developer';
// import 'dart:math' as m;
// import 'package:customer/api/api_value.dart';
// import 'package:customer/backend/driver_details_model.dart';
// import 'package:customer/backend/sockets.dart';
// import 'package:customer/components/text_style.dart';
// import 'package:customer/module_helper/app_info.dart';
// import 'package:customer/screen/navigation_screen.dart';
// import 'package:flutter/material.dart';
// import 'package:http/http.dart';
// import 'package:provider/provider.dart';
// import '../helper/button.dart';
// import '../screen/search_page_screen.dart';

// // Completer<List<Driver>> driversCompleter = Completer();
// // var parsedDrivers;

// // bool navigate = false;

// // Future<List<Driver>> driversFuture = driversCompleter.future;
// AvailableDriversModel? availablerDrivers;
// // late Future<List<Driver>> availableDrivers;
