import 'package:flutter/material.dart';


Widget logoImage(){
  return Image.asset('images/car_login.png', fit: BoxFit.cover,);
}